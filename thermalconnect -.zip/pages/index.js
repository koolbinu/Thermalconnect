import { useState } from "react";
import { motion } from "framer-motion";

export default function Home() {
  const [activeTab, setActiveTab] = useState("home");

  const sections = {
    home: (
      <div className="p-4 rounded-2xl shadow-md bg-white">
        <h1 className="text-xl font-bold text-center mb-2">Thermal Connect</h1>
        <p className="text-center text-base mb-4">
          Ab Bokaro Thermal (829107) me car rent aur bus ki jankari online.
          Safar ab hoga aur bhi aasan!
        </p>
        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => setActiveTab("cars")} className="bg-blue-500 text-white py-2 rounded-2xl">🚗 Car Rent</button>
          <button onClick={() => setActiveTab("buses")} className="bg-green-500 text-white py-2 rounded-2xl">🚌 Bus Info</button>
        </div>
      </div>
    ),
    cars: (
      <div className="p-4 rounded-2xl shadow-md bg-white">
        <h2 className="text-lg font-bold mb-2">Car Chahiye? Yahan Book Kijiye!</h2>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <img src="/car1.jpg" alt="Car 1" className="rounded-2xl" />
          <img src="/car2.jpg" alt="Car 2" className="rounded-2xl" />
        </div>
        <ul className="list-disc list-inside text-base space-y-1">
          <li>Local car owners apni gaadi register karte hain.</li>
          <li>Ab gaadi lene ke liye station ya chowk nahi jana hoga.</li>
          <li>Sirf call kijiye, driver aapke ghar aa jayega.</li>
        </ul>
        <button className="bg-blue-500 text-white py-2 w-full mt-4 rounded-2xl">📞 Booking ke liye Call karein</button>
      </div>
    ),
    buses: (
      <div className="p-4 rounded-2xl shadow-md bg-white">
        <h2 className="text-lg font-bold mb-2">Bus Kab Chalegi? Yahan Dekhiye!</h2>
        <p className="text-base mb-2">Bokaro Thermal se chalne wali buses ka time aur route.</p>
        <ul className="list-disc list-inside text-base space-y-1">
          <li>Ranchi, Bokaro, Dhanbad, Ramgarh ke liye buses.</li>
          <li>Updated time aur contact number milega.</li>
          <li>Ab bus station me wait karna nahi padega.</li>
        </ul>
        <button className="bg-green-500 text-white py-2 w-full mt-4 rounded-2xl">🚌 Bus Time Table Dekhein</button>
      </div>
    ),
    owners: (
      <div className="p-4 rounded-2xl shadow-md bg-white">
        <h2 className="text-lg font-bold mb-2">Apna Business Online Layein</h2>
        <p className="text-base mb-2">Car ya bus owners apni service yahan register karke zyada customers tak pahunchein.</p>
        <ul className="list-disc list-inside text-base space-y-1">
          <li>Free listing – koi extra paisa nahi.</li>
          <li>Aapka number seedha local logon ko dikhai dega.</li>
          <li>Bokaro Thermal ke liye safar aasan banaiye.</li>
        </ul>
        <button className="bg-yellow-500 text-white py-2 w-full mt-4 rounded-2xl">👥 Register Karein</button>
      </div>
    ),
    contact: (
      <div className="p-4 rounded-2xl shadow-md bg-white">
        <h2 className="text-lg font-bold mb-2">Contact Us</h2>
        <p className="text-base">📍 Bokaro Thermal, Jharkhand – 829107<br/>📞 Helpline / WhatsApp: +91-XXXXXXXXXX<br/>🌐 Website: www.thermalconnect.in</p>
      </div>
    ),
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 max-w-md mx-auto space-y-4 pb-20 bg-gray-100 min-h-screen">
      {sections[activeTab]}
      <div className="flex justify-around fixed bottom-0 left-0 right-0 bg-white p-2 shadow-inner">
        <button onClick={() => setActiveTab("home")} className={`rounded-2xl px-3 ${activeTab === 'home' ? 'bg-blue-500 text-white' : 'border'}`}>Home</button>
        <button onClick={() => setActiveTab("cars")} className={`rounded-2xl px-3 ${activeTab === 'cars' ? 'bg-blue-500 text-white' : 'border'}`}>Cars</button>
        <button onClick={() => setActiveTab("buses")} className={`rounded-2xl px-3 ${activeTab === 'buses' ? 'bg-blue-500 text-white' : 'border'}`}>Buses</button>
        <button onClick={() => setActiveTab("owners")} className={`rounded-2xl px-3 ${activeTab === 'owners' ? 'bg-blue-500 text-white' : 'border'}`}>Owners</button>
        <button onClick={() => setActiveTab("contact")} className={`rounded-2xl px-3 ${activeTab === 'contact' ? 'bg-blue-500 text-white' : 'border'}`}>Contact</button>
      </div>
    </motion.div>
  );
}